package mauriz.fran;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HolaSrpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(HolaSrpringApplication.class, args);
	}

}
